#!/usr/bin/env python3
"""
seed_waw.py — Seed the WaW LLP demo tenant (firm_id 'waw') into ParaIQ.

Schema confirmed against seed_guest.py and prior session output — NOT guessed:
  firms         (id, name, plan)                                    <- id IS the firm_id string
  public.users  (id, username, email, password_hash, role, plan,
                 firm_id, active, invited_at, created_at, last_login) <- schema-qualify: there is
                                                                          ALSO an auth.users (Supabase)
  cases         (id, firm_id, case_number, client_name, matter_number,
                 status, court, judge, filing_date, description,
                 risk_level, deleted, created_at, updated_at)
  case_documents(firm_id, case_id, document_name, source, doc_text,
                 sentiment, risk_score, events_json, entities_json,
                 summary, language, upload_date, pacer_doc_id, pacer_seq_no)
  case_notes    (firm_id, case_id, author, note, pinned, created_at)

Design choices (mirroring seed_guest.py conventions):
  * RLS context set with literal `SET app.current_firm_id = %s` (psycopg2 mogrifies
    this client-side into a literal before sending, so it works even though SET
    doesn't accept wire-protocol parameters).
  * `status` on `cases` IS the Kanban column — direct 1:1 mapping, no separate board table.
  * No `clients` table exists, so each VCF claimant = one `case`; full demographic /
    exposure / WTC-HP detail goes into a pinned "Client Intake Summary" case_note
    (author = assigned paralegal) rather than being split across tables that don't exist.
  * Each timeline event -> one case_note, created_at = event date, pinned=True for
    milestone event types (award_letter, claim_filed, wtchp_certification, case_closed).
  * Each intake image / medical-record PDF -> one case_documents row. For the two
    Vision-demo intake images, `doc_text` is pre-filled with the structured English
    extraction a Claude Vision pass would produce — so the case looks complete even
    before you run the live Vision demo, and you can diff live output against it.

Usage on VPS (from /root/nlp-portfolio):
    source .venv/bin/activate
    export DATABASE_URL="$(grep '^DATABASE_URL' .env | cut -d= -f2-)"
    python3 demo_docs/waw/seed_waw.py --dry-run      # preview, commits nothing
    python3 demo_docs/waw/seed_waw.py                # seed
    python3 demo_docs/waw/seed_waw.py --reset         # wipe firm 'waw' rows first, then seed

!! Only two things here are unverified assumptions — check them against auth.py
!! before running for real, then delete this warning block:
!!   1. users.role value — used 'firm_admin' below; swap for whatever your
!!      /auth/login and get_current_user() actually expect (e.g. 'attorney', 'paraiq_admin').
!!   2. Any UNIQUE constraint on users.username/email — script uses a bare
!!      ON CONFLICT DO NOTHING, which is safe regardless of the constraint name,
!!      but silently no-ops on a second run instead of updating. If you rerun
!!      after fixing a mistake, use --reset.
"""
import argparse
import json
import os
import sys

import bcrypt
import psycopg2
import psycopg2.extras
from dotenv import load_dotenv

load_dotenv("/root/nlp-portfolio/.env")

TARGET_FIRM = "waw"
DOCS_DIR = "/root/nlp-portfolio/demo_docs/waw"   # where you scp the PNG/PDF files alongside this script

MILESTONE_TYPES = {
    "award_letter", "claim_filed", "wtchp_certification", "case_closed",
    "retainer_signed", "vcf_registration", "payment_received", "disbursement",
}

# ---------------------------------------------------------------------------

def load_data():
    here = os.path.dirname(os.path.abspath(__file__))
    with open(os.path.join(here, "waw_seed_data.json"), encoding="utf-8") as f:
        return json.load(f)


def risk_level_for(client):
    conds = " ".join(c["condition"].lower() for c in client["conditions"])
    if "cancer" in conds or "carcinoma" in conds or "lymphoma" in conds or "myeloma" in conds:
        return "High"
    if "sarcoidosis" in conds or "severe" in conds:
        return "High"
    if "asthma" in conds or "copd" in conds or "lymphedema" in conds:
        return "Medium"
    return "Low"


def vision_extraction_stub(client, form_language):
    """Pre-filled structured extraction, as if Claude Vision had already scanned the
    handwritten intake form. Lets the case look complete pre-demo; live Vision output
    can be compared against this during the pitch."""
    c = client
    lines = [
        f"[Claude Vision structured extraction — source: handwritten intake, {form_language}]",
        f"Name: {c['name']}" + (f" ({c['name_native']})" if c.get("name_native") else ""),
        f"DOB: {c['dob']}  |  Gender: {c['gender']}  |  Age: {c['age']}",
        f"Address: {c['address']}",
        f"Phone: {c['phone']}",
        f"Exposure: {c['exposure_narrative']}",
        f"Employer: {c['exposure_category']}",
        "Diagnosed conditions: " + "; ".join(x["condition"] for x in c["conditions"]),
        f"WTC-HP enrolled: {c['wtc_hp'].get('enrolled') or 'not yet'}",
        f"Prior VCF filing: {'No — first filing' if not c.get('vcf_registration') else 'Registered ' + c['vcf_registration']}",
    ]
    return "\n".join(lines)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--reset", action="store_true", help="delete all firm 'waw' rows first")
    ap.add_argument("--dry-run", action="store_true", help="print planned inserts, commit nothing")
    args = ap.parse_args()

    data = load_data()
    dsn = os.environ.get("DATABASE_URL")
    if not dsn:
        sys.exit("DATABASE_URL not set — see usage note at top of this file.")

    conn = psycopg2.connect(dsn)
    cur = conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor)

    cur.execute("SET app.current_firm_id = %s", (TARGET_FIRM,))

    if args.reset:
        print(f"Resetting firm '{TARGET_FIRM}' ...")
        if not args.dry_run:
            cur.execute("DELETE FROM case_documents WHERE firm_id = %s", (TARGET_FIRM,))
            cur.execute("DELETE FROM case_notes WHERE firm_id = %s", (TARGET_FIRM,))
            cur.execute("DELETE FROM cases WHERE firm_id = %s", (TARGET_FIRM,))
            cur.execute("DELETE FROM public.users WHERE firm_id = %s", (TARGET_FIRM,))
            cur.execute("DELETE FROM firms WHERE id = %s", (TARGET_FIRM,))
            conn.commit()
            print("  cleared existing waw rows")
        else:
            print("  [dry] would DELETE from case_documents, case_notes, cases, public.users, firms")

    # ── firm ──────────────────────────────────────────────────────────────
    f = data["firm"]
    print(f"Seeding firm '{TARGET_FIRM}' ({f['name']}) ...")
    if not args.dry_run:
        cur.execute(
            "INSERT INTO firms (id, name, plan) VALUES (%s, %s, 'trial') ON CONFLICT DO NOTHING",
            (TARGET_FIRM, f["name"]),
        )

    # ── user ──────────────────────────────────────────────────────────────
    u = data["user"]
    pw_hash = bcrypt.hashpw(u["password_plain"].encode(), bcrypt.gensalt()).decode()
    print(f"Seeding user '{u['username']}' (role='{u['role']}' — VERIFY against auth.py) ...")
    if not args.dry_run:
        cur.execute(
            """INSERT INTO public.users
                   (username, email, password_hash, role, plan, firm_id, active, created_at)
               VALUES (%s, %s, %s, %s, 'trial', %s, TRUE, NOW())
               ON CONFLICT DO NOTHING""",
            (u["username"], u["email"], pw_hash, u["role"], TARGET_FIRM),
        )

    # ── cases (+ notes, + documents) ─────────────────────────────────────
    doc_index = {}
    for d in data["documents"]:
        doc_index.setdefault(d["client_key"], []).append(d)

    for i, c in enumerate(data["clients"], start=1):
        display = c["name"] + (f" ({c['name_native']})" if c.get("name_native") else "")
        print(f"[{i}/8] {display}  —  {c['kanban_stage']}")

        case_number = f"VCF-2026-{i:03d}"
        matter_number = f"WAW-{c['client_key'].upper()}"
        filing_events = [e for e in c["timeline"] if e["type"] == "claim_filed"]
        filing_date = filing_events[0]["date"] if filing_events else c["timeline"][0]["date"]
        description = (
            f"{c['claim_type']}. Claimant: {c['age']}yo {c['gender']}, {c['race_ethnicity']}. "
            f"Exposure: {c['exposure_category']}. "
            f"Conditions: {'; '.join(x['condition'] for x in c['conditions'])}."
        )

        if args.dry_run:
            print(f"    [dry] INSERT cases: {case_number}, status={c['kanban_stage']}, "
                  f"risk={risk_level_for(c)}")
            case_id = None
        else:
            cur.execute(
                """INSERT INTO cases
                       (firm_id, case_number, client_name, matter_number, status, court,
                        judge, filing_date, description, risk_level, deleted, created_at, updated_at)
                   VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s, FALSE, NOW(), NOW())
                   RETURNING id""",
                (TARGET_FIRM, case_number, display, matter_number, c["kanban_stage"],
                 "U.S. Department of Justice — September 11th VCF Claims Unit",
                 "N/A — Special Master review (VCF is not a court proceeding)",
                 filing_date, description, risk_level_for(c)),
            )
            case_id = cur.fetchone()["id"]

        # pinned intake summary note (stands in for the missing "clients" table)
        intake_summary = (
            f"CLIENT INTAKE SUMMARY\n"
            f"DOB: {c['dob']}  |  Age: {c['age']}  |  Gender: {c['gender']}  |  "
            f"Ethnicity: {c['race_ethnicity']}\n"
            f"Address: {c['address']}\nPhone: {c['phone']}"
            + (f"\nEmail: {c['email']}" if c.get("email") else "")
            + (f"\nPreferred language: {c['preferred_language']}" if c.get("preferred_language") else "")
            + (f"\nEmergency contact: {c['emergency_contact']}" if c.get("emergency_contact") else "")
            + f"\n\nExposure: {c['exposure_narrative']}\n"
            f"WTC-HP enrolled: {c['wtc_hp'].get('enrolled') or 'not yet'}; "
            f"certified: {', '.join(c['wtc_hp']['certified']) or 'none yet'}\n"
            f"VCF registration: {c.get('vcf_registration') or 'not yet registered'}\n"
            f"Assigned paralegal: {c['assigned_paralegal']}\n\n"
            f"Case notes: {c['notes']}"
        )
        if args.dry_run:
            print(f"    [dry] INSERT case_notes: intake summary (pinned)")
            print(f"    [dry] INSERT case_notes: {len(c['timeline'])} timeline events")
        else:
            cur.execute(
                """INSERT INTO case_notes (firm_id, case_id, author, note, pinned, created_at)
                   VALUES (%s,%s,%s,%s, TRUE, %s)""",
                (TARGET_FIRM, case_id, c["assigned_paralegal"], intake_summary, c["timeline"][0]["date"]),
            )
            for ev in c["timeline"]:
                pinned = ev["type"] in MILESTONE_TYPES
                note_text = f"[{ev['type']}] {ev['title']}" + (f"\n{ev['detail']}" if ev["detail"] else "")
                cur.execute(
                    """INSERT INTO case_notes (firm_id, case_id, author, note, pinned, created_at)
                       VALUES (%s,%s,%s,%s,%s,%s)""",
                    (TARGET_FIRM, case_id, c["assigned_paralegal"], note_text, pinned, ev["date"]),
                )

        # documents
        for d in doc_index.get(c["client_key"], []):
            is_intake_image = d["doc_type"] == "intake_form_scan"
            doc_text = vision_extraction_stub(c, d.get("language", "en")) if is_intake_image else \
                f"[Medical record on file: {d['description']}. Full text available in source PDF at " \
                f"{DOCS_DIR}/{d['filename']}]"
            if args.dry_run:
                print(f"    [dry] INSERT case_documents: {d['filename']}")
            else:
                cur.execute(
                    """INSERT INTO case_documents
                           (firm_id, case_id, document_name, source, doc_text, sentiment, risk_score,
                            events_json, entities_json, summary, language, upload_date,
                            pacer_doc_id, pacer_seq_no)
                       VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,NULL,NULL)""",
                    (TARGET_FIRM, case_id, d["filename"],
                     "Client intake (scanned)" if is_intake_image else "Medical provider records request",
                     doc_text, None, None,
                     json.dumps([]), json.dumps({}),
                     d["description"], d.get("language", "en"),
                     c["timeline"][0]["date"]),
                )

    if args.dry_run:
        print("\nDry run complete — nothing committed.")
        conn.rollback()
    else:
        conn.commit()
        print("\nCommitted. Verify tenant isolation:")
        print("  1) Log in as WaW / 11Bway  -> should see exactly 8 cases.")
        print("  2) Log in as maxwell (firm 'default') -> should see ZERO waw rows.")
        print("  3) Add firm 'waw' as a third tenant in the cross-tenant CI test matrix.")

    cur.close()
    conn.close()


if __name__ == "__main__":
    main()
